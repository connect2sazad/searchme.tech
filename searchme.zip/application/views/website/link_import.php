<link rel = "icon" href ="<?=base_url('assets/images/srch_it_logo.svg');?>" sizes="any"  type = "image/svg+xml">     
    <!-- CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-CuOF+2SnTUfTwSZjCXf01h7uYhfOBuxIhGKPbfEJ3+FqH/s6cIFN9bGr1HmAg4fQ" crossorigin="anonymous">        <!--Bootstrap-->

    <link rel="stylesheet" href="<?=base_url();?>/assets/css/space-system.css"> 
    <link rel="stylesheet" href="<?=base_url();?>/assets/css/style-common.css"> 

    <link rel="stylesheet" href="<?=base_url();?>/assets/css/style-nav-footer.css"> 


	

    <!-- FONTS-->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
